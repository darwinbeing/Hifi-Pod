//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by plugin_dlg.rc
//
#define IDD_CONFIG                      101
#define IDD_ABOUT                       106
#define IDB_LOGO                        107
#define VARBITRATE_CHK                  1004
#define THREAD_PRIORITY_SLIDER          1007
#define IDC_STATIC2                     1034
#define LOCAL_BUFFER_TXT                1035
#define STREAM_BUFFER_TXT               1036
#define IDC_MEMMAP                      1037
#define OK_BTN                          1038
#define CANCEL_BTN                      1039
#define RESET_BTN                       1047
#define IDC_LOGO                        1048
#define IDC_PLUGINVER                   1050
#define IDC_FAADVER                     1051
#define IDC_MAIL1                       1052
#define IDC_MAIL2                       1053
#define IDC_MAIL3                       1054

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1055
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
